
# Strive Advanced Medical Training Website

This is the official website code for Strive Advanced Medical Training.

## Deployment

1. Create a GitHub repository and upload this folder's contents.
2. Connect the repository to [Vercel](https://vercel.com) for free hosting.
3. Add environment variables in Vercel:
   - NEXT_PUBLIC_SUPABASE_URL
   - NEXT_PUBLIC_SUPABASE_ANON_KEY
   - NEXT_PUBLIC_PODCAST_RSS
   - NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
4. Deploy - your site will go live at `https://<your-project>.vercel.app`.

## Development

Run locally:
```bash
npm install
npm run dev
```
