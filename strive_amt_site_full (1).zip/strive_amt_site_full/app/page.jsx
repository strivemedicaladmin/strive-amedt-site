import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import ReactPlayer from "react-player";

export default function Home() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  );

  useEffect(() => {
    async function getUser() {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      setUser(user);
      setLoading(false);
    }
    getUser();
  }, []);

  const handleLogin = async () => {
    await supabase.auth.signInWithOAuth({ provider: "google" });
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
  };

  if (loading) return <p className="p-4 text-center">Loading...</p>;

  return (
    <main className="min-h-screen bg-gray-50 text-gray-900 flex flex-col items-center p-6">
      <header className="flex flex-col items-center space-y-4">
        <img src="/logo.png" alt="Strive AMT" className="h-24" />
        <h1 className="text-3xl font-bold">Strive Advanced Medical Training</h1>
        <p className="text-lg text-gray-600">
          Critical Care Paramedic Education & Resources
        </p>
      </header>

      <section className="mt-8 max-w-2xl w-full">
        {!user ? (
          <div className="text-center">
            <p className="mb-4">Sign in to access your course materials</p>
            <button
              onClick={handleLogin}
              className="bg-blue-600 text-white px-4 py-2 rounded-xl shadow hover:bg-blue-700"
            >
              Login with Google
            </button>
          </div>
        ) : (
          <div className="space-y-4 text-center">
            <p className="text-green-600">Welcome, {user.email}</p>
            <button
              onClick={handleLogout}
              className="bg-red-500 text-white px-4 py-2 rounded-xl shadow hover:bg-red-600"
            >
              Logout
            </button>
            <div className="bg-white shadow rounded-2xl p-4 mt-6">
              <h2 className="text-xl font-semibold mb-2">Podcast</h2>
              <ReactPlayer
                url="https://your-podcast-feed-url.com/episode1.mp3"
                controls
                width="100%"
              />
            </div>
          </div>
        )}
      </section>
    </main>
  );
}
